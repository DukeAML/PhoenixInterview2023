
const Helpers = require("./helpers");
var graceData = require("../../data/gracePeriods.json");
console.log(Helpers.calculatePeopleNeeded(false, "Black",100));



